import json

def lambda_handler(event, context):
    # Log the event data for debugging
    print("Received event: " + json.dumps(event, indent=2))

    # Your GitHub webhook processing logic goes here
    # You can access the GitHub webhook payload in the 'event' parameter

    return {
        'statusCode': 200,
        'body': json.dumps('GitHub Webhook received successfully!')
    }
